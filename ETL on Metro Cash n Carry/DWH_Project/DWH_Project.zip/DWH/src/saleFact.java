import java.sql.Date;

public class saleFact {
	
	
	
	
	
	public String TRANSACTION_ID;
	public String PRODUCT_ID;
	public String PRODUCT_NAME;
	public String SUPPLIER_ID;
	public String SUPPLIER_NAME;
	public String CUSTOMER_ID;
	public String CUSTOMER_NAME;
	public String STORE_ID;
	public String STORE_NAME;
	public Date T_DATE;
	public int QUANTITY;
	public int PRICE;
	public int TOTAL_SALE; 

}
