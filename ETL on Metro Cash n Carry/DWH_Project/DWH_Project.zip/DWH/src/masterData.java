

/**
 * @author Hamza
 *
 */
public class masterData {
	
	
	public String PRODUCT_ID;
	public String PRODUCT_NAME;
	public String SUPPLIER_ID;
	public String SUPPLIER_NAME;
	public int PRICE;

}
